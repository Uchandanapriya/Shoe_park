require 'test_helper'

class GalleryHelperTest < ActionView::TestCase
end
